# BAPTIST CHURCH UMUGUMA – Live Camera

Host shares a camera, anyone can join and watch.

## Publish on GitHub Pages
1. Create a new repository on github.com (Public).
2. Upload `index.html`, `.nojekyll` and `README.md` to the repository.
3. Go to Settings > Pages.
4. Under "Build and deployment", choose "Deploy from a branch", branch `main`, folder `/ (root)`, then Save.
5. After a minute your site is live at https://YOUR-USERNAME.github.io/REPOSITORY-NAME/
